package com.example.pokedexapp.data.remote.responses

data class AbilityX(
    val name: String,
    val url: String
)