package com.example.pokedexapp.data.remote.responses

data class TypeX(
    val name: String,
    val url: String
)