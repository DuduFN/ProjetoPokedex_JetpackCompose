package com.example.pokedexapp.data.remote.responses

data class Item(
    val name: String,
    val url: String
)