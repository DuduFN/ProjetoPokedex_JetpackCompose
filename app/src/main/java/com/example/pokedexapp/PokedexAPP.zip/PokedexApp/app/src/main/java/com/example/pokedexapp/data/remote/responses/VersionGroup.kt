package com.example.pokedexapp.data.remote.responses

data class VersionGroup(
    val name: String,
    val url: String
)