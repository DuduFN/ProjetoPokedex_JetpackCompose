package com.example.pokedexapp.data.remote.responses

data class GameIndice(
    val game_index: Int,
    val version: Version
)