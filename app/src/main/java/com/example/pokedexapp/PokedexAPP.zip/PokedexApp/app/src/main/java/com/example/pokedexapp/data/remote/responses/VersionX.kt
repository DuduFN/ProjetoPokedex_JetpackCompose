package com.example.pokedexapp.data.remote.responses

data class VersionX(
    val name: String,
    val url: String
)