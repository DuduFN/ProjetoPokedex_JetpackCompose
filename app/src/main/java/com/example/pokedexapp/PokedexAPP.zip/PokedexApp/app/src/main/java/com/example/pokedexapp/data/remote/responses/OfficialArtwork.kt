package com.example.pokedexapp.data.remote.responses

data class OfficialArtwork(
    val front_default: String
)