package com.example.pokedexapp.data.remote.responses

data class Icons(
    val front_default: String,
    val front_female: Any
)