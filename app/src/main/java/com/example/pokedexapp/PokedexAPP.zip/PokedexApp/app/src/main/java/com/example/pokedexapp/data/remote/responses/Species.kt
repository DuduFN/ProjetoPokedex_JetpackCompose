package com.example.pokedexapp.data.remote.responses

data class Species(
    val name: String,
    val url: String
)