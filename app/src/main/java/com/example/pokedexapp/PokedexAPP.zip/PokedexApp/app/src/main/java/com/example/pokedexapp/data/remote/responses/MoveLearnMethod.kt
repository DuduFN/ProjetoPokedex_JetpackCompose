package com.example.pokedexapp.data.remote.responses

data class MoveLearnMethod(
    val name: String,
    val url: String
)