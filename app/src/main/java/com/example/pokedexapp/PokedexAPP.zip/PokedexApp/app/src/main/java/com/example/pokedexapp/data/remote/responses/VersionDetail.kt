package com.example.pokedexapp.data.remote.responses

data class VersionDetail(
    val rarity: Int,
    val version: VersionX
)