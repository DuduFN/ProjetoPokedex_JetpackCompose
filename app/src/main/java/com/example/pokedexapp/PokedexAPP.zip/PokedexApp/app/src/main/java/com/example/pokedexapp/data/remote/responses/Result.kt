package com.example.pokedexapp.data.remote.responses

data class Result(
    val name: String,
    val url: String
)