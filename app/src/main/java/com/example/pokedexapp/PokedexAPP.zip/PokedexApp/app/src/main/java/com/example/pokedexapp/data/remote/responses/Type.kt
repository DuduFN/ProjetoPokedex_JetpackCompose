package com.example.pokedexapp.data.remote.responses

data class Type(
    val slot: Int,
    val type: TypeX
)