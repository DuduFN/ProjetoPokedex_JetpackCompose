package com.example.pokedexapp.data.remote.responses

data class GenerationViii(
    val icons: IconsX
)