package com.example.pokedexapp.data.remote.responses

data class Form(
    val name: String,
    val url: String
)