package com.example.pokedexapp.data.remote.responses

data class MoveX(
    val name: String,
    val url: String
)